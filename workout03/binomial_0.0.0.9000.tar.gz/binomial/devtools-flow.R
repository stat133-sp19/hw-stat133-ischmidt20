devtools::document()
devtools::check_man()
devtools::test()
devtools::build()
